<template>
  <h1>Volunteer</h1>
</template>

<script setup></script>

<style scoped></style>
