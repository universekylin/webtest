<template>
  <h1>About Us</h1>
</template>

<script setup></script>

<style scoped></style>
