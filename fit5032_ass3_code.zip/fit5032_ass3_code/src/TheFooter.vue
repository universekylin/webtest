<template>
  <div class="container">
    <footer class="py-3 my-4">
      <ul class="nav justify-content-center border-bottom pb-3 mb-3">
        <li class="nav-item">
          <router-link to="/" class="nav-link px-2 text-muted">Home</router-link>
        </li>
        <li class="nav-item">
          <router-link to="/Storynav/about-us" class="nav-link px-2 text-muted">About</router-link>
        </li>
        <li class="nav-item">
          <router-link to="/Storynav/our-service" class="nav-link px-2 text-muted"
            >Service</router-link
          >
        </li>
        <li class="nav-item">
          <router-link to="/Storynav/our-volunteer" class="nav-link px-2 text-muted"
            >Volunteer</router-link
          >
        </li>
      </ul>
      <p class="text-center text-muted">&copy; 2022 Company, Inc</p>
    </footer>
  </div>
</template>

<script setup></script>

<style scoped></style>
